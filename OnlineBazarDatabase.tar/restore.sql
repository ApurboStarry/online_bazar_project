--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.1
-- Dumped by pg_dump version 11.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE online_bazar;
--
-- Name: online_bazar; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE online_bazar WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'English_United States.1252' LC_CTYPE = 'English_United States.1252';


ALTER DATABASE online_bazar OWNER TO postgres;

\connect online_bazar

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: decrease_stock_quantity(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.decrease_stock_quantity() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
  begin
    update products
    set stock_quantity = stock_quantity - NEW.purchase_quantity
    where NEW.product_id = products.product_id;
  return new;
  end; $$;


ALTER FUNCTION public.decrease_stock_quantity() OWNER TO postgres;

--
-- Name: electronic_devices(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.electronic_devices() RETURNS TABLE(name character varying, des character varying, st_quantity integer, val real, disc real, avg_rating real, reviews integer, company character varying, color character varying, warr real, pic character varying)
    LANGUAGE plpgsql
    AS $$
  begin
    return query select  product_name, description, stock_quantity, price, discount, average_rating, no_of_reviews, company_name, colour, warranty, photo from products where category_id in (
  select category_id
  from category
  where category1 = 'Electronic Devices'
  );
  end; $$;


ALTER FUNCTION public.electronic_devices() OWNER TO postgres;

--
-- Name: insert_into_ac(character varying, character varying, integer, integer, real, real, character varying, character varying, real, character varying, character varying, character varying, double precision, integer, character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.insert_into_ac(p_name character varying, des character varying, cat_id integer, st_quantity integer, val real, disc real, comp_name character varying, color character varying, warr real, pic character varying, install_type character varying, room_sz character varying, capacty double precision, energy_star_rtng integer, coil_mtrl character varying, featrs character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
  begin
    insert into products(product_name, description, category_id, stock_quantity, price, discount, company_name, colour, warranty, photo)
    values (p_name, des, cat_id, st_quantity, val, disc, comp_name, color, warr, pic);
    insert into ac(product_id, installation_type, room_size, capacity, energy_star_rating, coil_material, features) 
    VALUES (currval(pg_get_serial_sequence('products', 'product_id')), install_type, room_sz, capacty, energy_star_rtng, coil_mtrl, featrs);
  end; $$;


ALTER FUNCTION public.insert_into_ac(p_name character varying, des character varying, cat_id integer, st_quantity integer, val real, disc real, comp_name character varying, color character varying, warr real, pic character varying, install_type character varying, room_sz character varying, capacty double precision, energy_star_rtng integer, coil_mtrl character varying, featrs character varying) OWNER TO postgres;

--
-- Name: insert_into_book(character varying, character varying, integer, integer, real, real, character varying, character varying, real, character varying, character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.insert_into_book(p_name character varying, des character varying, cat_id integer, st_quantity integer, val real, disc real, comp_name character varying, color character varying, warr real, pic character varying, _genre character varying, _author character varying, llanguage character varying, fformat character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
  begin
    insert into products(product_name, description, category_id, stock_quantity, price, discount, company_name, colour, warranty, photo)
    values (p_name, des, cat_id, st_quantity, val, disc, comp_name, color, warr, pic);
    insert into book(product_id, genre, author, _language, _format)
    VALUES (currval(pg_get_serial_sequence('products', 'product_id')), _genre, _author, llanguage, fformat);
  end; $$;


ALTER FUNCTION public.insert_into_book(p_name character varying, des character varying, cat_id integer, st_quantity integer, val real, disc real, comp_name character varying, color character varying, warr real, pic character varying, _genre character varying, _author character varying, llanguage character varying, fformat character varying) OWNER TO postgres;

--
-- Name: insert_into_category(character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.insert_into_category(cat1 character varying, cat2 character varying, cat3 character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
  begin
      if (select category_id
          from category
          where category1 = cat1 and category2 = cat2 and category3 = cat3) is null then
          insert into category(category1, category2, category3)
          VALUES (cat1, cat2, cat3);
      else
        raise exception 'Category already exists'
        using hint = 'check the parameters again';
      end if;
  end; $$;


ALTER FUNCTION public.insert_into_category(cat1 character varying, cat2 character varying, cat3 character varying) OWNER TO postgres;

--
-- Name: insert_into_customer(character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, integer, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.insert_into_customer(fname character varying, lname character varying, pnumber character varying, uname character varying, pass character varying, emailid character varying, hnumber character varying, hname character varying, strt character varying, cityname character varying, postcode integer, contry character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
  begin
    insert into location(house_no, house_name, street, city, postal_code, country)
    values (hNumber, hName, strt, cityName, postCode, contry);
    insert into customer(location_id, first_name, last_name, phone_number, user_name, password, email)
    values (currval(pg_get_serial_sequence('location', 'location_id')), fName, lName, pNumber, uName, pass, emailID);
  end; $$;


ALTER FUNCTION public.insert_into_customer(fname character varying, lname character varying, pnumber character varying, uname character varying, pass character varying, emailid character varying, hnumber character varying, hname character varying, strt character varying, cityname character varying, postcode integer, contry character varying) OWNER TO postgres;

--
-- Name: insert_into_laptop_desktop(character varying, character varying, integer, integer, real, real, character varying, character varying, real, character varying, integer, integer, character varying, character varying, character varying, character varying, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.insert_into_laptop_desktop(p_name character varying, des character varying, cat_id integer, st_quantity integer, val real, disc real, comp_name character varying, color character varying, warr real, pic character varying, _hdd integer, _ssd integer, procsr_type character varying, cpu_spd character varying, op_sys character varying, agp_card character varying, _ram integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
    insert into products(product_name, description, category_id, stock_quantity, price, discount, company_name, colour, warranty, photo)
    values (p_name, des, cat_id, st_quantity, val, disc, comp_name, color, warr, pic);
    insert into laptop_and_desktop (product_id, hdd, ssd, processor_type, cpu_speed, operating_system, graphics_card, ram)
    VALUES (currval(pg_get_serial_sequence('products', 'product_id')), _hdd, _ssd, procsr_type, cpu_spd, op_sys, agp_card, _ram);
  end;
$$;


ALTER FUNCTION public.insert_into_laptop_desktop(p_name character varying, des character varying, cat_id integer, st_quantity integer, val real, disc real, comp_name character varying, color character varying, warr real, pic character varying, _hdd integer, _ssd integer, procsr_type character varying, cpu_spd character varying, op_sys character varying, agp_card character varying, _ram integer) OWNER TO postgres;

--
-- Name: insert_into_mobile_tablet(character varying, character varying, integer, integer, real, real, character varying, character varying, real, character varying, integer, integer, character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.insert_into_mobile_tablet(p_name character varying, des character varying, cat_id integer, st_quantity integer, val real, disc real, comp_name character varying, color character varying, warr real, pic character varying, _ram integer, _rom integer, pr_type character varying, op_sys character varying, _gpu character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
  begin
    insert into products(product_name, description, category_id, stock_quantity, price, discount, company_name, colour, warranty, photo)
    values (p_name, des, cat_id, st_quantity, val, disc, comp_name, color, warr, pic);
    insert into mobile_and_tablet(product_id, ram, rom, processor_type, os, gpu)
    values (currval(pg_get_serial_sequence('products', 'product_id')), _RAM, _ROM, pr_type, op_sys, _GPU);
  end; $$;


ALTER FUNCTION public.insert_into_mobile_tablet(p_name character varying, des character varying, cat_id integer, st_quantity integer, val real, disc real, comp_name character varying, color character varying, warr real, pic character varying, _ram integer, _rom integer, pr_type character varying, op_sys character varying, _gpu character varying) OWNER TO postgres;

--
-- Name: insert_into_products(character varying, character varying, integer, integer, real, real, character varying, character varying, real, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.insert_into_products(p_name character varying, des character varying, cat_id integer, st_quantity integer, val real, disc real, comp_name character varying, color character varying, warr real, pic character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
  begin
    insert into products(product_name, description, category_id, stock_quantity, price, discount, company_name, colour, warranty, photo)
    values (p_name, des, cat_id, st_quantity, val, disc, comp_name, color, warr, pic);
  end; $$;


ALTER FUNCTION public.insert_into_products(p_name character varying, des character varying, cat_id integer, st_quantity integer, val real, disc real, comp_name character varying, color character varying, warr real, pic character varying) OWNER TO postgres;

--
-- Name: insert_into_refrigerator(character varying, character varying, integer, integer, real, real, character varying, character varying, real, character varying, character varying, double precision, integer, character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.insert_into_refrigerator(p_name character varying, des character varying, cat_id integer, st_quantity integer, val real, disc real, comp_name character varying, color character varying, warr real, pic character varying, door_st character varying, capcty double precision, energy_str_rating integer, featrs character varying, defrst_sys character varying, door_patrn character varying, shelf_typ character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
  begin
    insert into products(product_name, description, category_id, stock_quantity, price, discount, company_name, colour, warranty, photo)
    values (p_name, des, cat_id, st_quantity, val, disc, comp_name, color, warr, pic);
    insert into refrigerator(product_id, door_style, capacity, energy_star_rating, features, defrost_system, door_pattern, shelf_type)
    VALUES (currval(pg_get_serial_sequence('products', 'product_id')), door_st, capcty, energy_str_rating, featrs, defrst_sys, door_patrn, shelf_typ);
  end; $$;


ALTER FUNCTION public.insert_into_refrigerator(p_name character varying, des character varying, cat_id integer, st_quantity integer, val real, disc real, comp_name character varying, color character varying, warr real, pic character varying, door_st character varying, capcty double precision, energy_str_rating integer, featrs character varying, defrst_sys character varying, door_patrn character varying, shelf_typ character varying) OWNER TO postgres;

--
-- Name: insert_into_tv(character varying, character varying, integer, integer, real, real, character varying, character varying, real, character varying, double precision, character varying, character varying, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.insert_into_tv(p_name character varying, des character varying, cat_id integer, st_quantity integer, val real, disc real, comp_name character varying, color character varying, warr real, pic character varying, scrn_size double precision, disp_tech character varying, hd_frmt character varying, num_of_usb_port integer, num_of_hdmi_port integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
  begin
    insert into products(product_name, description, category_id, stock_quantity, price, discount, company_name, colour, warranty, photo)
    values (p_name, des, cat_id, st_quantity, val, disc, comp_name, color, warr, pic);
    insert into tv(product_id, screen_size, display_technology, hd_format, number_of_usb_port, number_of_hdmi_port) 
    VALUES (currval(pg_get_serial_sequence('products', 'product_id')), scrn_size, disp_tech, hd_frmt, num_of_usb_port, num_of_hdmi_port);
  end; $$;


ALTER FUNCTION public.insert_into_tv(p_name character varying, des character varying, cat_id integer, st_quantity integer, val real, disc real, comp_name character varying, color character varying, warr real, pic character varying, scrn_size double precision, disp_tech character varying, hd_frmt character varying, num_of_usb_port integer, num_of_hdmi_port integer) OWNER TO postgres;

--
-- Name: recommended_for_you(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.recommended_for_you(customer integer) RETURNS TABLE(name character varying, des character varying, st_quantity integer, val real, disc real, avg_rating real, reviews integer, company character varying, color character varying, warr real, pic character varying)
    LANGUAGE plpgsql
    AS $$
  begin
    return query select product_name, description, stock_quantity, price, discount, average_rating, no_of_reviews, company_name, colour, warranty, photo
    from products p
    where p.category_id in (select category_id
    from products p
    where p.product_id in (select product_id
    from customer_order
    where customer_id = customer));
  end; $$;


ALTER FUNCTION public.recommended_for_you(customer integer) OWNER TO postgres;

--
-- Name: review_trigger(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.review_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
  begin
    if (select no_of_reviews from products where NEW.product_id = products.product_id) = 0 then
      update products
      set no_of_reviews = 1,
          average_rating = NEW.star
      where NEW.product_id = products.product_id;
    else
      update products
      set no_of_reviews = no_of_reviews + 1,
          average_rating = (average_rating * (no_of_reviews-1)/no_of_reviews) + NEW.star / no_of_reviews
      where NEW.product_id = products.product_id;
    end if;

  return NEW;
  end; $$;


ALTER FUNCTION public.review_trigger() OWNER TO postgres;

--
-- Name: top_deals(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.top_deals() RETURNS TABLE(name character varying, des character varying, st_quantity integer, val real, disc real, avg_rating real, reviews integer, company character varying, color character varying, warr real, pic character varying)
    LANGUAGE plpgsql
    AS $$
  begin
    return query select product_name, description, stock_quantity, price, discount, average_rating, no_of_reviews, company_name, colour, warranty, photo
    from products
    WHERE discount >= 0.2
    order by discount DESC ;
  end; $$;


ALTER FUNCTION public.top_deals() OWNER TO postgres;

--
-- Name: top_rated(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.top_rated() RETURNS TABLE(name character varying, des character varying, st_quantity integer, val real, disc real, avg_rating real, reviews integer, company character varying, color character varying, warr real, pic character varying)
    LANGUAGE plpgsql
    AS $$
  begin
    return query select product_name, description, stock_quantity, price, discount, average_rating, no_of_reviews, company_name, colour, warranty, photo
    from products
    where average_rating >= 4.3
    ORDER BY average_rating DESC ;
  end; $$;


ALTER FUNCTION public.top_rated() OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: ac; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ac (
    product_id integer NOT NULL,
    installation_type character varying(50),
    room_size character varying(50),
    capacity double precision,
    energy_star_rating integer,
    coil_material character varying(50),
    features character varying(50)
);


ALTER TABLE public.ac OWNER TO postgres;

--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    product_id integer NOT NULL,
    product_name character varying(100) NOT NULL,
    description character varying(200) NOT NULL,
    category_id integer,
    stock_quantity integer,
    price real,
    discount real,
    average_rating real DEFAULT 0.0,
    no_of_reviews integer DEFAULT 0.0,
    company_name character varying(50) NOT NULL,
    colour character varying(20),
    warranty real,
    photo character varying(100) NOT NULL,
    CONSTRAINT products_discount_check CHECK (((discount >= (0.0)::double precision) AND (discount <= (1)::double precision))),
    CONSTRAINT products_price_check CHECK ((price >= (0.0)::double precision)),
    CONSTRAINT products_stock_quantity_check CHECK ((stock_quantity >= 0))
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: ac_view; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.ac_view AS
 SELECT products.product_id,
    products.product_name,
    products.description,
    products.category_id,
    products.stock_quantity,
    products.price,
    products.discount,
    products.average_rating,
    products.no_of_reviews,
    products.company_name,
    products.colour,
    products.warranty,
    products.photo,
    ac.installation_type,
    ac.room_size,
    ac.capacity,
    ac.energy_star_rating,
    ac.coil_material,
    ac.features
   FROM (public.products
     JOIN public.ac USING (product_id));


ALTER TABLE public.ac_view OWNER TO postgres;

--
-- Name: book; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.book (
    product_id integer NOT NULL,
    genre character varying(50) NOT NULL,
    author character varying(50) NOT NULL,
    _language character varying(50) NOT NULL,
    _format character varying(50) NOT NULL
);


ALTER TABLE public.book OWNER TO postgres;

--
-- Name: book_view; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.book_view AS
 SELECT products.product_id,
    products.product_name,
    products.description,
    products.category_id,
    products.stock_quantity,
    products.price,
    products.discount,
    products.average_rating,
    products.no_of_reviews,
    products.company_name,
    products.colour,
    products.warranty,
    products.photo,
    book.genre,
    book.author,
    book._language,
    book._format
   FROM (public.products
     JOIN public.book USING (product_id));


ALTER TABLE public.book_view OWNER TO postgres;

--
-- Name: cart; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cart (
    customer_id integer,
    product_id integer
);


ALTER TABLE public.cart OWNER TO postgres;

--
-- Name: category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.category (
    category_id integer NOT NULL,
    category1 character varying(50) NOT NULL,
    category2 character varying(50) NOT NULL,
    category3 character varying(50)
);


ALTER TABLE public.category OWNER TO postgres;

--
-- Name: category_category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.category_category_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.category_category_id_seq OWNER TO postgres;

--
-- Name: category_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.category_category_id_seq OWNED BY public.category.category_id;


--
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    customer_id integer NOT NULL,
    location_id integer,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    phone_number character varying(11) NOT NULL,
    user_name character varying(50) NOT NULL,
    password character varying(50) NOT NULL,
    card_name character varying(50),
    card_no character varying(50),
    email character varying(100) NOT NULL
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- Name: customer_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customer_customer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customer_customer_id_seq OWNER TO postgres;

--
-- Name: customer_customer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customer_customer_id_seq OWNED BY public.customer.customer_id;


--
-- Name: customer_order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer_order (
    order_id integer NOT NULL,
    customer_id integer,
    product_id integer,
    purchase_quantity integer,
    confirmation boolean,
    order_date date NOT NULL,
    shipping_date date,
    payment_method character varying(50),
    delivery_status character varying(20) DEFAULT 'shipped'::character varying,
    staff_id integer NOT NULL,
    shipping_address character varying(100) NOT NULL,
    CONSTRAINT customer_order_delivery_status_check CHECK (((delivery_status)::text = ANY ((ARRAY['shipped'::character varying, 'delivered'::character varying])::text[]))),
    CONSTRAINT customer_order_purchase_quantity_check CHECK ((purchase_quantity > 0))
);


ALTER TABLE public.customer_order OWNER TO postgres;

--
-- Name: customer_order_order_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customer_order_order_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customer_order_order_id_seq OWNER TO postgres;

--
-- Name: customer_order_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customer_order_order_id_seq OWNED BY public.customer_order.order_id;


--
-- Name: laptop_and_desktop; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.laptop_and_desktop (
    product_id integer NOT NULL,
    hdd integer,
    ssd integer,
    processor_type character varying(50) NOT NULL,
    cpu_speed character varying(50) NOT NULL,
    operating_system character varying(50) NOT NULL,
    graphics_card character varying(50),
    ram integer
);


ALTER TABLE public.laptop_and_desktop OWNER TO postgres;

--
-- Name: laptop_and_desktop_view; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.laptop_and_desktop_view AS
 SELECT products.product_id,
    products.product_name,
    products.description,
    products.category_id,
    products.stock_quantity,
    products.price,
    products.discount,
    products.average_rating,
    products.no_of_reviews,
    products.company_name,
    products.colour,
    products.warranty,
    products.photo,
    laptop_and_desktop.hdd,
    laptop_and_desktop.ssd,
    laptop_and_desktop.processor_type,
    laptop_and_desktop.cpu_speed,
    laptop_and_desktop.operating_system,
    laptop_and_desktop.graphics_card,
    laptop_and_desktop.ram
   FROM (public.products
     JOIN public.laptop_and_desktop USING (product_id));


ALTER TABLE public.laptop_and_desktop_view OWNER TO postgres;

--
-- Name: location; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.location (
    location_id integer NOT NULL,
    house_no character varying(50) NOT NULL,
    house_name character varying(50) NOT NULL,
    street character varying(50) NOT NULL,
    city character varying(50) NOT NULL,
    postal_code integer,
    country character varying(50) NOT NULL
);


ALTER TABLE public.location OWNER TO postgres;

--
-- Name: location_location_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.location_location_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.location_location_id_seq OWNER TO postgres;

--
-- Name: location_location_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.location_location_id_seq OWNED BY public.location.location_id;


--
-- Name: mobile_and_tablet; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mobile_and_tablet (
    product_id integer NOT NULL,
    ram integer NOT NULL,
    rom integer NOT NULL,
    processor_type character varying(100) NOT NULL,
    os character varying(30) NOT NULL,
    gpu character varying(50)
);


ALTER TABLE public.mobile_and_tablet OWNER TO postgres;

--
-- Name: mobile_tablet_view; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.mobile_tablet_view AS
 SELECT products.product_id,
    products.product_name,
    products.description,
    products.category_id,
    products.stock_quantity,
    products.price,
    products.discount,
    products.average_rating,
    products.no_of_reviews,
    products.company_name,
    products.colour,
    products.warranty,
    products.photo,
    mobile_and_tablet.ram,
    mobile_and_tablet.rom,
    mobile_and_tablet.processor_type,
    mobile_and_tablet.os,
    mobile_and_tablet.gpu
   FROM (public.products
     JOIN public.mobile_and_tablet USING (product_id));


ALTER TABLE public.mobile_tablet_view OWNER TO postgres;

--
-- Name: products_product_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.products_product_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_product_id_seq OWNER TO postgres;

--
-- Name: products_product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.products_product_id_seq OWNED BY public.products.product_id;


--
-- Name: refrigerator; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.refrigerator (
    product_id integer NOT NULL,
    door_style character varying(50),
    capacity double precision,
    energy_star_rating integer,
    features character varying(50),
    defrost_system character varying(50),
    door_pattern character varying(50),
    shelf_type character varying(50)
);


ALTER TABLE public.refrigerator OWNER TO postgres;

--
-- Name: refrigerator_view; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.refrigerator_view AS
 SELECT products.product_id,
    products.product_name,
    products.description,
    products.category_id,
    products.stock_quantity,
    products.price,
    products.discount,
    products.average_rating,
    products.no_of_reviews,
    products.company_name,
    products.colour,
    products.warranty,
    products.photo,
    refrigerator.door_style,
    refrigerator.capacity,
    refrigerator.energy_star_rating,
    refrigerator.features,
    refrigerator.defrost_system,
    refrigerator.door_pattern,
    refrigerator.shelf_type
   FROM (public.products
     JOIN public.refrigerator USING (product_id));


ALTER TABLE public.refrigerator_view OWNER TO postgres;

--
-- Name: review; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.review (
    review_id integer NOT NULL,
    customer_id integer,
    product_id integer,
    star integer NOT NULL,
    comment character varying(100),
    order_id integer
);


ALTER TABLE public.review OWNER TO postgres;

--
-- Name: review_review_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.review_review_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.review_review_id_seq OWNER TO postgres;

--
-- Name: review_review_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.review_review_id_seq OWNED BY public.review.review_id;


--
-- Name: staff; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.staff (
    staff_id integer NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    phone_no character varying(11) NOT NULL,
    salary integer NOT NULL,
    email character varying(50),
    join_date date DEFAULT CURRENT_DATE NOT NULL
);


ALTER TABLE public.staff OWNER TO postgres;

--
-- Name: staff_staff_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.staff_staff_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.staff_staff_id_seq OWNER TO postgres;

--
-- Name: staff_staff_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.staff_staff_id_seq OWNED BY public.staff.staff_id;


--
-- Name: tv; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tv (
    product_id integer NOT NULL,
    screen_size double precision NOT NULL,
    display_technology character varying(50),
    hd_format character varying(50),
    number_of_usb_port integer,
    number_of_hdmi_port integer
);


ALTER TABLE public.tv OWNER TO postgres;

--
-- Name: tv_view; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.tv_view AS
 SELECT products.product_id,
    products.product_name,
    products.description,
    products.category_id,
    products.stock_quantity,
    products.price,
    products.discount,
    products.average_rating,
    products.no_of_reviews,
    products.company_name,
    products.colour,
    products.warranty,
    products.photo,
    tv.screen_size,
    tv.display_technology,
    tv.hd_format,
    tv.number_of_usb_port,
    tv.number_of_hdmi_port
   FROM (public.products
     JOIN public.tv USING (product_id));


ALTER TABLE public.tv_view OWNER TO postgres;

--
-- Name: category category_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category ALTER COLUMN category_id SET DEFAULT nextval('public.category_category_id_seq'::regclass);


--
-- Name: customer customer_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer ALTER COLUMN customer_id SET DEFAULT nextval('public.customer_customer_id_seq'::regclass);


--
-- Name: customer_order order_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_order ALTER COLUMN order_id SET DEFAULT nextval('public.customer_order_order_id_seq'::regclass);


--
-- Name: location location_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.location ALTER COLUMN location_id SET DEFAULT nextval('public.location_location_id_seq'::regclass);


--
-- Name: products product_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products ALTER COLUMN product_id SET DEFAULT nextval('public.products_product_id_seq'::regclass);


--
-- Name: review review_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review ALTER COLUMN review_id SET DEFAULT nextval('public.review_review_id_seq'::regclass);


--
-- Name: staff staff_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff ALTER COLUMN staff_id SET DEFAULT nextval('public.staff_staff_id_seq'::regclass);


--
-- Data for Name: ac; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ac (product_id, installation_type, room_size, capacity, energy_star_rating, coil_material, features) FROM stdin;
\.
COPY public.ac (product_id, installation_type, room_size, capacity, energy_star_rating, coil_material, features) FROM '$$PATH$$/2995.dat';

--
-- Data for Name: book; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.book (product_id, genre, author, _language, _format) FROM stdin;
\.
COPY public.book (product_id, genre, author, _language, _format) FROM '$$PATH$$/2991.dat';

--
-- Data for Name: cart; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cart (customer_id, product_id) FROM stdin;
\.
COPY public.cart (customer_id, product_id) FROM '$$PATH$$/2999.dat';

--
-- Data for Name: category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.category (category_id, category1, category2, category3) FROM stdin;
\.
COPY public.category (category_id, category1, category2, category3) FROM '$$PATH$$/2984.dat';

--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer (customer_id, location_id, first_name, last_name, phone_number, user_name, password, card_name, card_no, email) FROM stdin;
\.
COPY public.customer (customer_id, location_id, first_name, last_name, phone_number, user_name, password, card_name, card_no, email) FROM '$$PATH$$/2982.dat';

--
-- Data for Name: customer_order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer_order (order_id, customer_id, product_id, purchase_quantity, confirmation, order_date, shipping_date, payment_method, delivery_status, staff_id, shipping_address) FROM stdin;
\.
COPY public.customer_order (order_id, customer_id, product_id, purchase_quantity, confirmation, order_date, shipping_date, payment_method, delivery_status, staff_id, shipping_address) FROM '$$PATH$$/2988.dat';

--
-- Data for Name: laptop_and_desktop; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.laptop_and_desktop (product_id, hdd, ssd, processor_type, cpu_speed, operating_system, graphics_card, ram) FROM stdin;
\.
COPY public.laptop_and_desktop (product_id, hdd, ssd, processor_type, cpu_speed, operating_system, graphics_card, ram) FROM '$$PATH$$/2993.dat';

--
-- Data for Name: location; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.location (location_id, house_no, house_name, street, city, postal_code, country) FROM stdin;
\.
COPY public.location (location_id, house_no, house_name, street, city, postal_code, country) FROM '$$PATH$$/2980.dat';

--
-- Data for Name: mobile_and_tablet; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mobile_and_tablet (product_id, ram, rom, processor_type, os, gpu) FROM stdin;
\.
COPY public.mobile_and_tablet (product_id, ram, rom, processor_type, os, gpu) FROM '$$PATH$$/2992.dat';

--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (product_id, product_name, description, category_id, stock_quantity, price, discount, average_rating, no_of_reviews, company_name, colour, warranty, photo) FROM stdin;
\.
COPY public.products (product_id, product_name, description, category_id, stock_quantity, price, discount, average_rating, no_of_reviews, company_name, colour, warranty, photo) FROM '$$PATH$$/2986.dat';

--
-- Data for Name: refrigerator; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.refrigerator (product_id, door_style, capacity, energy_star_rating, features, defrost_system, door_pattern, shelf_type) FROM stdin;
\.
COPY public.refrigerator (product_id, door_style, capacity, energy_star_rating, features, defrost_system, door_pattern, shelf_type) FROM '$$PATH$$/2996.dat';

--
-- Data for Name: review; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.review (review_id, customer_id, product_id, star, comment, order_id) FROM stdin;
\.
COPY public.review (review_id, customer_id, product_id, star, comment, order_id) FROM '$$PATH$$/2990.dat';

--
-- Data for Name: staff; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.staff (staff_id, first_name, last_name, phone_no, salary, email, join_date) FROM stdin;
\.
COPY public.staff (staff_id, first_name, last_name, phone_no, salary, email, join_date) FROM '$$PATH$$/2998.dat';

--
-- Data for Name: tv; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tv (product_id, screen_size, display_technology, hd_format, number_of_usb_port, number_of_hdmi_port) FROM stdin;
\.
COPY public.tv (product_id, screen_size, display_technology, hd_format, number_of_usb_port, number_of_hdmi_port) FROM '$$PATH$$/2994.dat';

--
-- Name: category_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.category_category_id_seq', 42, true);


--
-- Name: customer_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customer_customer_id_seq', 22, true);


--
-- Name: customer_order_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customer_order_order_id_seq', 29, true);


--
-- Name: location_location_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.location_location_id_seq', 18, true);


--
-- Name: products_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.products_product_id_seq', 38, true);


--
-- Name: review_review_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.review_review_id_seq', 10, true);


--
-- Name: staff_staff_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.staff_staff_id_seq', 1, true);


--
-- Name: ac ac_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ac
    ADD CONSTRAINT ac_pkey PRIMARY KEY (product_id);


--
-- Name: book book_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book
    ADD CONSTRAINT book_pkey PRIMARY KEY (product_id);


--
-- Name: category category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category
    ADD CONSTRAINT category_pkey PRIMARY KEY (category_id);


--
-- Name: customer_order customer_order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_order
    ADD CONSTRAINT customer_order_pkey PRIMARY KEY (order_id);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (customer_id);


--
-- Name: laptop_and_desktop laptop_and_desktop_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.laptop_and_desktop
    ADD CONSTRAINT laptop_and_desktop_pkey PRIMARY KEY (product_id);


--
-- Name: location location_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.location
    ADD CONSTRAINT location_pkey PRIMARY KEY (location_id);


--
-- Name: mobile_and_tablet mobile_and_tablet_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mobile_and_tablet
    ADD CONSTRAINT mobile_and_tablet_pkey PRIMARY KEY (product_id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (product_id);


--
-- Name: refrigerator refrigerator_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refrigerator
    ADD CONSTRAINT refrigerator_pkey PRIMARY KEY (product_id);


--
-- Name: review review_order_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT review_order_id_key UNIQUE (order_id);


--
-- Name: review review_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT review_pkey PRIMARY KEY (review_id);


--
-- Name: staff staff_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_pkey PRIMARY KEY (staff_id);


--
-- Name: tv tv_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tv
    ADD CONSTRAINT tv_pkey PRIMARY KEY (product_id);


--
-- Name: customer_email_uindex; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX customer_email_uindex ON public.customer USING btree (email);


--
-- Name: customer_phone_number_uindex; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX customer_phone_number_uindex ON public.customer USING btree (phone_number);


--
-- Name: customer_order change_stock_quantity; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER change_stock_quantity BEFORE INSERT ON public.customer_order FOR EACH ROW EXECUTE PROCEDURE public.decrease_stock_quantity();


--
-- Name: review update_review; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_review BEFORE INSERT ON public.review FOR EACH ROW EXECUTE PROCEDURE public.review_trigger();


--
-- Name: ac ac_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ac
    ADD CONSTRAINT ac_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: book book_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book
    ADD CONSTRAINT book_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cart cart_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart
    ADD CONSTRAINT cart_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer(customer_id);


--
-- Name: cart cart_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart
    ADD CONSTRAINT cart_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id);


--
-- Name: customer customer_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.location(location_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: customer_order customer_order_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_order
    ADD CONSTRAINT customer_order_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer(customer_id) ON UPDATE CASCADE;


--
-- Name: customer_order customer_order_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_order
    ADD CONSTRAINT customer_order_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id) ON UPDATE CASCADE;


--
-- Name: customer_order customer_order_staff_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_order
    ADD CONSTRAINT customer_order_staff_id_fkey FOREIGN KEY (staff_id) REFERENCES public.staff(staff_id) ON DELETE RESTRICT;


--
-- Name: laptop_and_desktop laptop_and_desktop_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.laptop_and_desktop
    ADD CONSTRAINT laptop_and_desktop_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: mobile_and_tablet mobile_and_tablet_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mobile_and_tablet
    ADD CONSTRAINT mobile_and_tablet_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: products products_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.category(category_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: refrigerator refrigerator_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refrigerator
    ADD CONSTRAINT refrigerator_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: review review_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT review_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer(customer_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: review review_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT review_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.customer_order(order_id);


--
-- Name: review review_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT review_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tv tv_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tv
    ADD CONSTRAINT tv_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

